# FeatureAdmin
SharePoint Feature Administration and Clean Up Tool

Tool to find and delete broken features in a SharePoint farm

See https://featureadmin.codeplex.com/
and https://github.com/SharePointPog/FeatureAdmin
